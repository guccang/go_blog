go mod tidy
go build
