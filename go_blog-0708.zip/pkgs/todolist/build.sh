#!/bin/bash
go build 